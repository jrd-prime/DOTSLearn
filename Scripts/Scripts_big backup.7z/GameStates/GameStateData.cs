﻿using Unity.Entities;

namespace Jrd.GameStates
{
    public struct GameStateData : IComponentData
    {
        public Entity GameStateEntity;
    }
}