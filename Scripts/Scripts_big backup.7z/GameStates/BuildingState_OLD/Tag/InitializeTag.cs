﻿using Unity.Entities;

namespace Jrd.GameStates.BuildingState_OLD.Tag
{
    public struct InitializeTag : IComponentData
    {
        
    }
}