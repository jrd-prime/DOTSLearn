﻿using Unity.Entities;

namespace Jrd.GameStates.BuildingState_OLD
{
    public struct BSApplyPanelComponent : IComponentData
    {
        public bool ShowPanel;
        public bool IsVisible;
    }
}