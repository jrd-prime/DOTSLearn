﻿using Unity.Entities;

namespace Jrd.GameStates.BuildingState_OLD
{
    public struct BSBuildingsPanelComponent : IComponentData
    {
        public bool Visibility;
    }
}