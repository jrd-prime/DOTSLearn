﻿namespace Jrd
{
    public static class UIConst
    {
        public static string ApplyPanelCancelBtnName = "cancel-button";
        public static string ApplyPanelApplyBtnName = "apply-button";
    }
}