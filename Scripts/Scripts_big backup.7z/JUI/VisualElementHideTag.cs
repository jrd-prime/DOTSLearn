﻿using Unity.Entities;

namespace Jrd.JUI
{
    public struct VisualElementHideTag : IComponentData
    {
        
    }
}