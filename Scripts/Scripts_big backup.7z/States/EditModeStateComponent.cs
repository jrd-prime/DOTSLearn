﻿using Unity.Entities;

namespace Jrd.States
{
    public struct EditModeStateComponent : IComponentData
    {
        public bool State;
    }
}