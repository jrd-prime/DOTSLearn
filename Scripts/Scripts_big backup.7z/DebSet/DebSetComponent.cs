﻿using Unity.Entities;

namespace Jrd.DebSet
{
    public struct DebSetComponent : IComponentData
    {
        public bool MouseRaycast;
    }
}