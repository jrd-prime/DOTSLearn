﻿using Unity.Entities;

namespace Jrd.UserInput
{
    public struct ZoomingEventComponent : IComponentData
    {
        public float zoom;
    }
}