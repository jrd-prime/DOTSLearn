using Unity.Entities;

namespace Jrd.JCamera
{
    public struct CameraComponent : IComponentData
    {
    }
}