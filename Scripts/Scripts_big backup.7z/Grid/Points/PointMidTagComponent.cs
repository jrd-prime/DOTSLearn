﻿using Unity.Entities;

namespace Jrd.Grid.Points
{
    public struct PointMidTagComponent: IComponentData
    {
        
    }
}