﻿using Unity.Entities;

namespace Jrd.Grid.Points
{
    public struct PointSmallTagComponent: IComponentData
    {
        
    }
}