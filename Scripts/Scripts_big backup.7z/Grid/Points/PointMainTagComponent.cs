﻿using Unity.Entities;

namespace Jrd.Grid.Points
{
    public struct PointMainTagComponent: IComponentData
    {
        
    }
}